# Rasterization Checker

* `g++` should be on your path
* Download and put your `1805XXX.zip` file inside the `submissions` folder
* From command line / terminal, run `python checker.py`
* Observe the output
* Tested for Windows, should work on Linux too